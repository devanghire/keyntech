<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-24 04:16:58 --> Severity: Warning --> Array to string conversion C:\wamp64\www\keyntech\application\models\Category_model.php 41
ERROR - 2025-01-24 07:53:54 --> Severity: error --> Exception: Call to undefined method User_model::list() C:\wamp64\www\keyntech\application\controllers\Dashboard.php 16
ERROR - 2025-01-24 08:04:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\keyntech\application\controllers\Dashboard.php 17
ERROR - 2025-01-24 08:04:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\keyntech\application\controllers\Dashboard.php 18
ERROR - 2025-01-24 08:28:13 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting ":" C:\wamp64\www\keyntech\application\models\Category_model.php 87
ERROR - 2025-01-24 08:38:09 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\wamp64\www\keyntech\application\models\Category_model.php 96
ERROR - 2025-01-24 08:42:09 --> Severity: error --> Exception: syntax error, unexpected token "." C:\wamp64\www\keyntech\application\models\Category_model.php 98
ERROR - 2025-01-24 09:31:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 75
ERROR - 2025-01-24 09:31:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 75
ERROR - 2025-01-24 09:35:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 75
ERROR - 2025-01-24 09:51:39 --> Severity: error --> Exception: syntax error, unexpected variable "$existingParentAddChildCategory" C:\wamp64\www\keyntech\application\models\Category_model.php 57
ERROR - 2025-01-24 09:51:39 --> Severity: error --> Exception: syntax error, unexpected variable "$existingParentAddChildCategory" C:\wamp64\www\keyntech\application\models\Category_model.php 57
ERROR - 2025-01-24 09:51:42 --> Severity: error --> Exception: syntax error, unexpected variable "$existingParentAddChildCategory" C:\wamp64\www\keyntech\application\models\Category_model.php 57
ERROR - 2025-01-24 09:51:45 --> Severity: error --> Exception: syntax error, unexpected variable "$existingParentAddChildCategory" C:\wamp64\www\keyntech\application\models\Category_model.php 57
ERROR - 2025-01-24 09:55:19 --> Severity: error --> Exception: syntax error, unexpected token "echo" C:\wamp64\www\keyntech\application\models\Category_model.php 42
ERROR - 2025-01-24 11:05:21 --> Severity: Warning --> Undefined array key "message" C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:09:36 --> Severity: Warning --> Undefined array key "message" C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:09:42 --> Severity: Warning --> Undefined array key "message" C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:12:38 --> Severity: Warning --> Undefined array key "message" C:\wamp64\www\keyntech\application\models\Category_model.php 136
ERROR - 2025-01-24 11:12:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:12:47 --> Severity: Warning --> Undefined array key "message" C:\wamp64\www\keyntech\application\models\Category_model.php 136
ERROR - 2025-01-24 11:12:47 --> Severity: Warning --> Trying to access array offset on value of type bool C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:14:13 --> Severity: Warning --> Undefined array key "message" C:\wamp64\www\keyntech\application\models\Category_model.php 136
ERROR - 2025-01-24 11:14:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:15:19 --> Severity: error --> Exception: Cannot access offset of type string on string C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 76
ERROR - 2025-01-24 11:29:58 --> Severity: Warning --> Undefined variable $response C:\wamp64\www\keyntech\application\models\Category_model.php 8
