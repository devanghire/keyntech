<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-23 15:47:45 --> 404 Page Not Found: Category_api/index
ERROR - 2025-01-23 15:47:45 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:47:45 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_404.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:50:34 --> 404 Page Not Found: Category_api/index
ERROR - 2025-01-23 15:50:34 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:50:34 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_404.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:52:32 --> 404 Page Not Found: Category_api/index
ERROR - 2025-01-23 15:52:32 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:52:32 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_404.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:52:34 --> 404 Page Not Found: Category_api/index
ERROR - 2025-01-23 15:52:34 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:52:34 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_404.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:52:39 --> 404 Page Not Found: Category_api/index
ERROR - 2025-01-23 15:52:39 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:52:39 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_404.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 15:53:00 --> Severity: error --> Exception: Class "MX_Controller" not found C:\wamp64\www\keyntech\application\libraries\REST_Controller.php 16
ERROR - 2025-01-23 15:53:00 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:53:01 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:53:02 --> Severity: error --> Exception: Class "MX_Controller" not found C:\wamp64\www\keyntech\application\libraries\REST_Controller.php 16
ERROR - 2025-01-23 15:53:02 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:53:03 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:54:08 --> Severity: Warning --> require_once(C:\wamp64\www\keyntech\application\libraries\REST_Controller.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 3
ERROR - 2025-01-23 15:54:08 --> Severity: error --> Exception: Failed opening required 'C:\wamp64\www\keyntech\application\libraries\REST_Controller.php' (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 3
ERROR - 2025-01-23 15:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\keyntech\system\core\Exceptions.php:272) C:\wamp64\www\keyntech\system\core\Common.php 571
ERROR - 2025-01-23 15:54:08 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:54:08 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:57:07 --> Severity: Warning --> require(C:\wamp64\www\keyntech\application\/libraries/REST_Controller.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 5
ERROR - 2025-01-23 15:57:07 --> Severity: error --> Exception: Failed opening required 'C:\wamp64\www\keyntech\application\/libraries/REST_Controller.php' (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 5
ERROR - 2025-01-23 15:57:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\keyntech\system\core\Exceptions.php:272) C:\wamp64\www\keyntech\system\core\Common.php 571
ERROR - 2025-01-23 15:57:08 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:57:08 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:59:33 --> Severity: Warning --> require(C:\wamp64\www\keyntech\application\/libraries/REST_Controller.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 5
ERROR - 2025-01-23 15:59:33 --> Severity: error --> Exception: Failed opening required 'C:\wamp64\www\keyntech\application\/libraries/REST_Controller.php' (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 5
ERROR - 2025-01-23 15:59:33 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 15:59:33 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 16:00:42 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 8
ERROR - 2025-01-23 16:00:42 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 16:00:42 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 220
ERROR - 2025-01-23 16:02:34 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 8
ERROR - 2025-01-23 16:03:03 --> Severity: error --> Exception: Class "RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 8
ERROR - 2025-01-23 16:03:43 --> Severity: error --> Exception: Class "RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:03:48 --> Severity: error --> Exception: Class "RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:05:00 --> Severity: error --> Exception: Class "RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:08:16 --> Severity: error --> Exception: Class "RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:08:20 --> Severity: error --> Exception: Class "RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:11:00 --> Severity: error --> Exception: Class "keyntech\Libraries\RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:11:21 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\keyntech\application\controllers\api\Category_api.php 9
ERROR - 2025-01-23 16:13:40 --> Severity: Warning --> include(C:\wamp64\www\keyntech\application\views\errors\html\error_general.php): Failed to open stream: No such file or directory C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 16:13:40 --> Severity: Warning --> include(): Failed opening 'C:\wamp64\www\keyntech\application\views\errors\html\error_general.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\keyntech\system\core\Exceptions.php 183
ERROR - 2025-01-23 16:17:18 --> Severity: error --> Exception: Class "chriskacerguis\RestServer\Format" not found C:\wamp64\www\keyntech\application\libraries\RestController.php 361
ERROR - 2025-01-23 16:55:52 --> Query error: Table 'logical_wings.categories' doesn't exist - Invalid query: SELECT *
FROM `categories`
ERROR - 2025-01-23 16:55:52 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\keyntech\application\models\Category_model.php 12
ERROR - 2025-01-23 18:07:55 --> Severity: Warning --> Undefined variable $key C:\wamp64\www\keyntech\application\views\dashboard.php 135
ERROR - 2025-01-23 18:08:01 --> Severity: Warning --> Undefined variable $key C:\wamp64\www\keyntech\application\views\dashboard.php 135
ERROR - 2025-01-23 18:08:08 --> Severity: Warning --> Undefined variable $key C:\wamp64\www\keyntech\application\views\dashboard.php 135
ERROR - 2025-01-23 18:13:02 --> Severity: Warning --> Undefined variable $key C:\wamp64\www\keyntech\application\views\dashboard.php 134
