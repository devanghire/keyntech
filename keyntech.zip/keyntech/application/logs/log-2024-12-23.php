ERROR - 2024-12-23 18:23:13 --> Unable to delete cache file for 
ERROR - 2024-12-23 18:23:15 --> Unable to delete cache file for 
ERROR - 2024-12-23 18:28:10 --> 404 Page Not Found: Dashboard/viewdata
ERROR - 2024-12-23 19:24:36 --> 404 Page Not Found: Add/index
ERROR - 2024-12-23 19:24:40 --> 404 Page Not Found: View/index
ERROR - 2024-12-23 19:29:16 --> 404 Page Not Found: Uploads/download2.jpg
ERROR - 2024-12-23 19:29:41 --> 404 Page Not Found: Uploads/download2.jpg
ERROR - 2024-12-23 19:31:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-12-23 19:31:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-12-23 19:32:34 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-12-23 19:32:34 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-12-23 19:33:25 --> 404 Page Not Found: Assets/profile_picturesdownload2.jpg
ERROR - 2024-12-23 19:34:55 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:35:43 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:36:04 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:36:43 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:36:51 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:37:36 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:37:43 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:39:03 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 19:39:25 --> The upload path does not appear to be valid.
ERROR - 2024-12-23 20:59:52 --> Severity: error --> Exception: syntax error, unexpected token "if", expecting "," or ";" C:\laragon\www\logicalwings\application\models\User_model.php 32
ERROR - 2024-12-23 20:59:52 --> Severity: Warning --> include(C:\laragon\www\logicalwings\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\laragon\www\logicalwings\system\core\Exceptions.php 220
ERROR - 2024-12-23 20:59:52 --> Severity: Warning --> include(): Failed opening 'C:\laragon\www\logicalwings\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:/laragon/etc/php/pear') C:\laragon\www\logicalwings\system\core\Exceptions.php 220
ERROR - 2024-12-23 20:59:58 --> Severity: error --> Exception: syntax error, unexpected token "if", expecting "," or ";" C:\laragon\www\logicalwings\application\models\User_model.php 32
ERROR - 2024-12-23 20:59:58 --> Severity: Warning --> include(C:\laragon\www\logicalwings\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\laragon\www\logicalwings\system\core\Exceptions.php 220
ERROR - 2024-12-23 20:59:58 --> Severity: Warning --> include(): Failed opening 'C:\laragon\www\logicalwings\application\views\errors\html\error_exception.php' for inclusion (include_path='.;C:/laragon/etc/php/pear') C:\laragon\www\logicalwings\system\core\Exceptions.php 220
