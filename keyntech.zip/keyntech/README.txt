Category Management:


Requirements:

PHP 7.2 or greater
CodeIgniter 3.1.11+
wampp or xampp or laragon


Used : - 

* CodeIgniter 3 framework
* CodeIgniter RestServer
 


Setup instructions.

* Copy the project folder in (wampp or xampp or laragon) / www folder
* copy databse name keyntech and import in phpmyadmin
* run url in brawser http://localhost/keyntech


project description: - 

in this project user who have role like admin and editor. they manupulate the category data
like add delete update.
role type viewer is only view the data in his session


login credentials are available on homepage below the login form 